from PIL import Image
import numpy as np
import os
import random
os.chdir(os.path.dirname(__file__))
filename = "menuTitle.png"
img = Image.open(filename)

original_color = [255, 255, 255]


#      put t in quotes for transparency, c for change color
what_function = "t"


def transparency():

    rgba = img.convert("RGBA")
    datas = rgba.getdata()

    newData = []
    for item in datas:
        if item[0] == original_color[0] and item[1] == original_color[1] and item[2] == original_color[2]: # finding yellow colour
            # replacing it with a transparent value
            newData.append((255, 255, 255, 0))
        else:
            newData.append(item)

    rgba.putdata(newData)
    rgba.save(filename, "PNG")



def change_color():

    #new colors
    color_1 = [105, 105, 105]
    color_2 = [94, 94, 94]
    color_3 = [84, 84, 84]
    color_4 = [77, 77, 77]

    width = img.size[0] 
    height = img.size[1] 
    for i in range(0,width):# process all pixels
        for j in range(0,height):
            data = img.getpixel((i,j))
            #print(data) #(255, 255, 255)
            if (data[0]==original_color[0] and data[1]==original_color[1] and data[2]==original_color[2]):
                colordecider = random.randint(1,30)
                if colordecider < 11:
                    img.putpixel((i,j),(color_1[0],color_1[1], color_1[2]))
                if colordecider > 10 and colordecider < 21:
                    img.putpixel((i,j),(color_2[0],color_2[1], color_2[2]))
                if colordecider > 20 and colordecider < 31:
                    img.putpixel((i,j),(color_3[0],color_3[1], color_3[2]))
                if colordecider > 30:
                    img.putpixel((i,j),(color_4[0],color_4[1], color_4[2]))
    img.save("Armor 4 New.png")


if what_function == "t":
    transparency()
elif what_function == "c":
    change_color()
