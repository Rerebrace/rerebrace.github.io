# a funny minesweeper version

